2 minutes of combined ECG and COER sensor data.
COER sensor used in differential mode
COER sensor was placed on left wrist, close to the path of the radial artery
ECG was lead 1 (left arm, right arm, right leg)